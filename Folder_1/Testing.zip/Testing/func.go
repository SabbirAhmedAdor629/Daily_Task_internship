package Testing

import (
	"fmt"
	"strings"
	"time"
)

func main(){
	// times := getPrimeTime(0)
	// fmt.Println(times)

	// times := scheduleTimes()
	// fmt.Println(times)\
	
	c_hour := userCurrentHour(-5)
	fmt.Println(c_hour)
}




// TEST 1
func scheduleTimes() []string {
	var times []string

	times = append(times, []string{
		"Prime Time Best",
		"Prime Time Morning",
		"Prime Time Afternoon",
		"Prime Time Evening",
		"Prime Time Swing",
	}...)

	for _, tz := range []string{"User", "PT", "GMT"} {
		for hour := 0; hour < 24; hour++ {
			tIndicator := "am"
			if hour > 11 {
				tIndicator = "pm"
			}
			t, _ := time.Parse("3:04 pm", fmt.Sprintf("%d:00 %s", hour%12, tIndicator))
			times = append(times, fmt.Sprintf("%s %s", tz, t.Format("03pm")))
		}
	}

	return times
}

//TEST 2
func getScheduleTimeZone(schedule_time_index int) string {
	scheduleTimeList := scheduleTimes()
	if schedule_time_index < 0 || schedule_time_index >= len(scheduleTimeList) {
		return ""
	}
	scheduleTime := scheduleTimeList[schedule_time_index]
	return strings.Split(scheduleTime, " ")[0]
}

//TEST 3
func getScheduleTimeOfDay(schedule_time_index int) string {
	scheduleTimeList := scheduleTimes()
	if schedule_time_index < 0 || schedule_time_index >= len(scheduleTimeList) {
		return ""
	}
	scheduleTime := scheduleTimeList[schedule_time_index]
	scheduleTimeArray := strings.Split(scheduleTime, " ")
	return scheduleTimeArray[len(scheduleTimeArray)-1]
}

//TEST 4
func getPrimeTime(schedule_time_index int) string {
	if schedule_time_index < 0 {
		return ""
	}
	return strings.ToLower(getScheduleTimeOfDay(schedule_time_index))
}

//TEST 5
func getUserTime(schedule_time_index int) string {
	if schedule_time_index < 0 {
		return ""
	}
	return getScheduleTimeZone(schedule_time_index)
}

// TEST 6
func userLocalHour(hr int, userTimeZoneOffset int) int {
	localHr := hr + userTimeZoneOffset
	if localHr < 0 {
		return localHr + 24					// if the localHr+24 > 12 (then return localHr+24-12)
	} else {
		return localHr
	}
}

// TEST 7
func userCurrentHour(userTimeZoneOffset int) int {
	currentTime := time.Now().UTC().Add(time.Hour * (time.Duration(userTimeZoneOffset)))
	return currentTime.Hour()
}

// TEST 8
func userCurrentTime(userTimeZoneOffset int) string {
	currentTime := time.Now().UTC().Add(time.Hour * (time.Duration(userTimeZoneOffset)))
	return currentTime.Format("03pm")
}

// TEST 9
func AvailableKeyInMap(mapData map[string]interface{}, keyList ...string) bool {
	for _, key := range keyList {
		if val, ok := mapData[key]; !ok || val == nil {
			return false
		}
	}
	return true
}