package main

import (
	"os"
	"strconv"
	"strings"

	"influencemobile.com/logging"
)

type TypeEnvVar int

const (
	ENV_ENVIRONMENT TypeEnvVar = iota
	ENV_APPLICATION_NAME
	ENV_LOG_LEVEL
	ENV_AWS_REGION
	ENV_PARAMETERS_STORE
	ENV_DYNAMO_CONSENT_TABLE_NAME
	ENV_DYNAMO_MAPPING_TABLE_NAME
	ENV_CLOUDFRONT_HOST_URL
	ENV_DYNAMO_API_KEYS_TABLE_NAME
	ENV_TIMESTAMP_LIMIT_SECONDS
)

var (
	EnvVars = []string{
		ENV_ENVIRONMENT:                "TARGET_ENVIRONMENT",
		ENV_APPLICATION_NAME:           "APP_NAME",
		ENV_LOG_LEVEL:                  "LOG_LEVEL",
		ENV_AWS_REGION:                 "REGION",
		ENV_PARAMETERS_STORE:           "PARAMETERS_STORE",
		ENV_DYNAMO_CONSENT_TABLE_NAME:  "DYNAMO_CONSENT_TABLE_NAME",
		ENV_DYNAMO_MAPPING_TABLE_NAME:  "DYNAMO_MAPPING_TABLE_NAME",
		ENV_CLOUDFRONT_HOST_URL:        "CLOUDFRONT_HOST_URL",
		ENV_DYNAMO_API_KEYS_TABLE_NAME: "API_KEYS_TABLE_NAME",
		ENV_TIMESTAMP_LIMIT_SECONDS:    "TIMESTAMP_LIMIT_SECONDS",
	}
)

// Retrive region, sqs name, kinesis firehose name from lambda environment values
type envVars struct {
	LogLevel               int    `json:"LOG_LEVEL"`
	Environment            string `json:"TARGET_ENVIRONMENT"`
	ApplicationName        string `json:"APP_NAME"`
	region                 string `json:"REGION"`
	ParametersStore        string `json:"PARAMETERS_STORE"`
	DynamoConsentTableName string `json:"CONSENT_DYNAMO_TABLE_NAME"`
	DynamoMappingTableName string `json:"MAPPING_TABLE_NAME"`
	DynamoApiKeysTableName string `json:"API_KEYS_TABLE_NAME"`
	CloudfrontHostUrl      string `json:"CLOUDFRONT_HOST_URL"`
	TimestampLimitSeconds  int    `json:"TIMESTAMP_LIMIT_SECONDS"`
}

func NewEnv() envVars {
	return envVars{
		LogLevel:               getLogLevel(),
		Environment:            getEnvironment(),
		ApplicationName:        getApplicationName(),
		region:                 getRegion(),
		ParametersStore:        getParametersStore(),
		DynamoConsentTableName: getDynamoConsentTableName(),
		DynamoMappingTableName: getDynamoMappingTableName(),
		DynamoApiKeysTableName: getDynamoApiKeyTableName(),
		CloudfrontHostUrl:      getCloudfrontHostUrl(),
		TimestampLimitSeconds:  getTimestampLimitSeconds(),
	}
}

func getLogLevel() int {
	txtLevel := strings.ToUpper(os.Getenv(EnvVars[ENV_LOG_LEVEL]))
	level := DEFAULT_LOG_LEVEL
	for i, l := range logging.LogLevelText {
		if txtLevel == l {
			level = i
		}
	}
	return level
}

func getApplicationName() string {
	val, ok := os.LookupEnv(EnvVars[ENV_APPLICATION_NAME])
	if !ok {
		return DEFAULT_APPLICATION_NAME
	}
	return val
}

func getEnvironment() string     { return os.Getenv(EnvVars[ENV_ENVIRONMENT]) }
func getRegion() string          { return os.Getenv(EnvVars[ENV_AWS_REGION]) }
func getParametersStore() string { return os.Getenv(EnvVars[ENV_PARAMETERS_STORE]) }

func getDynamoConsentTableName() string {
	val, ok := os.LookupEnv(EnvVars[ENV_DYNAMO_CONSENT_TABLE_NAME])
	if !ok {
		return DEFAULT_DYNAMO_CONSENT_TABLE_NAME
	}
	return val
}

func getDynamoMappingTableName() string {
	val, ok := os.LookupEnv(EnvVars[ENV_DYNAMO_MAPPING_TABLE_NAME])
	if !ok {
		return DEFAULT_DYNAMO_MAPPING_TABLE_NAME
	}
	return val
}

func getDynamoApiKeyTableName() string { return os.Getenv(EnvVars[ENV_DYNAMO_API_KEYS_TABLE_NAME]) }

func getCloudfrontHostUrl() string { return os.Getenv(EnvVars[ENV_CLOUDFRONT_HOST_URL]) }

func getTimestampLimitSeconds() int {
	val, ok := os.LookupEnv(EnvVars[ENV_TIMESTAMP_LIMIT_SECONDS])
	if !ok {
		return DEFAULT_TIMESTAMP_LIMIT_SECONDS
	}

	limit, err := strconv.Atoi(val)
	if err != nil {
		return DEFAULT_TIMESTAMP_LIMIT_SECONDS
	}

	return limit
}
