package main

import (
	"context"
	"fmt"
	"os"
	"reflect"
	"testing"

	"github.com/aws/aws-lambda-go/events"
	v3 "influencemobile.com/libs/v3_helpers"
	im_config "influencemobile.com/parameter_store"
)

func setEnvVars(es map[TypeEnvVar]string) {
	for k, v := range es {
		os.Setenv(EnvVars[k], v)
	}
}

func TestGetQueryStringParams(t *testing.T) {
	type args struct {
		request events.APIGatewayProxyRequest
	}
	type test struct {
		name         string
		args         args
		expectedResp *QueryStringParams
		expectedErr  error
	}
	tests := []test{
		{
			name: "#1. Valid QueryStringParams",
			args: args{
				request: events.APIGatewayProxyRequest{
					QueryStringParameters: map[string]string{
						"timezone": "Europe/London",
					},
				},
			},
			expectedResp: &QueryStringParams{
				Timezone: "Europe/London",
			},
			expectedErr: nil,
		},
		{
			name: "#2. Empty QueryStringParams",
			args: args{
				request: events.APIGatewayProxyRequest{
					QueryStringParameters: map[string]string{},
				},
			},
			expectedResp: &QueryStringParams{},
			expectedErr:  nil,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got, err := getQueryStringParams(tt.args.request)
			if !reflect.DeepEqual(got, tt.expectedResp) {
				t.Errorf("getQueryStringParams() got = %v, expected = %v", got, tt.expectedResp)
			}
			if err != tt.expectedErr {
				t.Errorf("getQueryStringParams() error = %v, expected error = %v", err, tt.expectedErr)
			}
		})
	}
}

func TestSetJurisdiction(t *testing.T) {
	type args struct {
		timezone string
	}
	type test struct {
		name     string
		args     args
		expected string
	}
	tests := []test{
		{
			name: "#1. European timezone",
			args: args{
				timezone: "Europe/London",
			},
			expected: "gdpr",
		},
		{
			name: "#2. Non-European timezone",
			args: args{
				timezone: "Asia/Tokyo",
			},
			expected: "",
		},
		{
			name: "#3. Empty timezone",
			args: args{
				timezone: "",
			},
			expected: "",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			result := SetJurisdiction(tt.args.timezone)
			if !reflect.DeepEqual(result, tt.expected) {
				t.Errorf("SetJurisdiction() returned %v, but expected %v", result, tt.expected)
			}
		})
	}
}

func TestSetConsentUrl(t *testing.T) {
	type args struct {
		hostUrl      string
		jurisdiction string
		language     string
		documentType string
		version      string
	}
	type test struct {
		name        string
		args        args
		expectedUrl string
	}
	tests := []test{
		{
			name: "#1. Valid input",
			args: args{
				hostUrl:      "https://example.com",
				jurisdiction: "gdpr",
				language:     "en-uk",
				documentType: "pp",
				version:      "1680166802",
			},
			expectedUrl: "https://example.com/agreement/gdpr/en-uk/pp/1680166802/pp.html",
		},
		{
			name: "#2. Valid input",
			args: args{
				hostUrl:      "https://example.com",
				jurisdiction: "gdpr",
				language:     "en-ca",
				documentType: "pp",
				version:      "1680166789",
			},
			expectedUrl: "https://example.com/agreement/gdpr/en-ca/pp/1680166789/pp.html",
		},
		{
			name: "#3. Valid input",
			args: args{
				hostUrl:      "https://example.com",
				jurisdiction: "gdpr",
				language:     "en-uk",
				documentType: "tou",
				version:      "1680166788",
			},
			expectedUrl: "https://example.com/agreement/gdpr/en-uk/tou/1680166788/tou.html",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got := SetConsentUrl(tt.args.hostUrl, tt.args.jurisdiction, tt.args.language, tt.args.documentType, tt.args.version)
			if !reflect.DeepEqual(got, tt.expectedUrl) {
				t.Errorf("SetConsentUrl() got = %v, expected = %v", got, tt.expectedUrl)
			}
		})
	}
}

func TestCreateAgreement(t *testing.T) {
	type args struct {
		jurisdiction string
		agreement    string
		version      string
		locale       string
	}
	type test struct {
		name     string
		args     args
		expected Agreement
	}
	tests := []test{
		{
			name: "#1. CreateAgreement() with valid input",
			args: args{
				jurisdiction: "gdpr",
				agreement:    "tou",
				version:      "1680166789",
				locale:       "en-uk",
			},
			expected: Agreement{
				Jurisdiction: "gdpr",
				Agreement:    "tou",
				Version:      "1680166789",
				Locale:       "en-uk",
				URL:          SetConsentUrl(env.CloudfrontHostUrl, "gdpr", "en-uk", "tou", "1680166789"),
			},
		},
		{
			name: "#2. CreateAgreement() with valid input",
			args: args{
				jurisdiction: "gdpr",
				agreement:    "pp",
				version:      "1680166802",
				locale:       "en-uk",
			},
			expected: Agreement{
				Jurisdiction: "gdpr",
				Agreement:    "pp",
				Version:      "1680166802",
				Locale:       "en-uk",
				URL:          SetConsentUrl(env.CloudfrontHostUrl, "gdpr", "en-uk", "pp", "1680166802"),
			},
		},
		{
			name: "#3. CreateAgreement() with random input",
			args: args{
				jurisdiction: "eu",
				agreement:    "pp",
				version:      "1680166902",
				locale:       "en-us",
			},
			expected: Agreement{
				Jurisdiction: "eu",
				Agreement:    "pp",
				Version:      "1680166902",
				Locale:       "en-us",
				URL:          SetConsentUrl(env.CloudfrontHostUrl, "eu", "en-us", "pp", "1680166902"),
			},
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got := CreateAgreement(tt.args.jurisdiction, tt.args.agreement, tt.args.version, tt.args.locale)
			if !reflect.DeepEqual(got, tt.expected) {
				t.Errorf("CreateAgreement() = %v, want %v", got, tt.expected)
			}
		})
	}
}

func TestValidateRequestPath(t *testing.T) {
	type args struct {
		request events.APIGatewayProxyRequest
	}
	tests := []struct {
		name    string
		args    args
		want    *events.APIGatewayProxyResponse
		wantErr error
	}{
		// API: /api/v1/required_agreements
		{
			name: "#1: When request path is valid for [ /api/v1/required_agreements ]",
			args: args{
				request: events.APIGatewayProxyRequest{
					Resource:   "/api/v1/required_agreements",
					Path:       "/api/v1/required_agreements",
					HTTPMethod: "GET",
					Headers: map[string]string{
						"Content-Type": "application/json",
						"api_key":      "test-3",
						"request_id":   "C713F659-1ABF-4EDF-8E86-655295CF7CD7",
					},
					QueryStringParameters: map[string]string{
						"timezone": "Europe/London",
					},
					PathParameters: map[string]string{
						"proxy": "example",
					},
					Body:            "",
					IsBase64Encoded: false,
					RequestContext: events.APIGatewayProxyRequestContext{
						AccountID:  "123456789012",
						ResourceID: "resource-id",
						Stage:      "prod",
						RequestID:  "request-id",
						Identity: events.APIGatewayRequestIdentity{
							CognitoIdentityPoolID: "",
							AccountID:             "",
							CognitoIdentityID:     "",
							Caller:                "",
							APIKey:                "",
							SourceIP:              "127.0.0.1",
							AccessKey:             "",
						},
					},
				},
			},
			want:    nil,
			wantErr: nil,
		},
		{
			name: "#2: Invalid Request path",
			args: args{
				request: events.APIGatewayProxyRequest{
					Resource:   "/api/v1/required",
					Path:       "/api/v1/required",
					HTTPMethod: "GET",
					Headers: map[string]string{
						"Content-Type": "application/json",
						"api_key":      "test-3",
						"request_id":   "C713F659-1ABF-4EDF-8E86-655295CF7CD7",
					},
					QueryStringParameters: map[string]string{
						"timezone": "Europe/London",
					},
					PathParameters: map[string]string{
						"proxy": "example",
					},
					Body:            "",
					IsBase64Encoded: false,
					RequestContext: events.APIGatewayProxyRequestContext{
						AccountID:  "123456789012",
						ResourceID: "resource-id",
						Stage:      "prod",
						RequestID:  "request-id",
						Identity: events.APIGatewayRequestIdentity{
							CognitoIdentityPoolID: "",
							AccountID:             "",
							CognitoIdentityID:     "",
							Caller:                "",
							APIKey:                "",
							SourceIP:              "127.0.0.1",
							AccessKey:             "",
						},
					},
				},
			},
			want: &events.APIGatewayProxyResponse{
				StatusCode:      200,
				Headers:         responseHeaders,
				Body:            string(createResponseBody(int(v3.ResponseInvalidRequestPath), nil)),
				IsBase64Encoded: false,
			},
			wantErr: fmt.Errorf("Invalid Path"),
		},
		// API: /api/v1/required_agreements/{player_id}
		{
			name: "#3: When request path is valid for [ /api/v1/required_agreements/12001 ]",
			args: args{
				request: events.APIGatewayProxyRequest{
					Resource:   "/api/v1/required_agreements/{player_id}",
					Path:       "/api/v1/required_agreements/12001",
					HTTPMethod: "GET",
					Headers: map[string]string{
						"Content-Type": "application/json",
						"api_key":      "test-3",
						"request_id":   "C713F659-1ABF-4EDF-8E86-655295CF7CD7",
					},
					QueryStringParameters: map[string]string{
						"timezone": "Europe/London",
					},
					PathParameters: map[string]string{
						"proxy": "example",
					},
					Body:            "",
					IsBase64Encoded: false,
					RequestContext: events.APIGatewayProxyRequestContext{
						AccountID:  "123456789012",
						ResourceID: "resource-id",
						Stage:      "prod",
						RequestID:  "request-id",
						Identity: events.APIGatewayRequestIdentity{
							CognitoIdentityPoolID: "",
							AccountID:             "",
							CognitoIdentityID:     "",
							Caller:                "",
							APIKey:                "",
							SourceIP:              "127.0.0.1",
							AccessKey:             "",
						},
					},
				},
			},
			want:    nil,
			wantErr: nil,
		},
		{
			name: "#4: When request path is invalid for [ /api/v1/required_agreements/12001 ]",
			args: args{
				request: events.APIGatewayProxyRequest{
					Resource:   "/api/v1/required_agreements/12001/12321",
					Path:       "/api/v1/required_agreements/12002/123213",
					HTTPMethod: "GET",
					Headers: map[string]string{
						"Content-Type": "application/json",
						"api_key":      "test-3",
						"request_id":   "C713F659-1ABF-4EDF-8E86-655295CF7CD7",
					},
					QueryStringParameters: map[string]string{
						"timezone": "Europe/London",
					},
					PathParameters: map[string]string{
						"proxy": "example",
					},
					Body:            "",
					IsBase64Encoded: false,
					RequestContext: events.APIGatewayProxyRequestContext{
						AccountID:  "123456789012",
						ResourceID: "resource-id",
						Stage:      "prod",
						RequestID:  "request-id",
						Identity: events.APIGatewayRequestIdentity{
							CognitoIdentityPoolID: "",
							AccountID:             "",
							CognitoIdentityID:     "",
							Caller:                "",
							APIKey:                "",
							SourceIP:              "127.0.0.1",
							AccessKey:             "",
						},
					},
				},
			},
			want: &events.APIGatewayProxyResponse{
				StatusCode:      200,
				Headers:         responseHeaders,
				Body:            string(createResponseBody(int(v3.ResponseInvalidRequestPath), nil)),
				IsBase64Encoded: false,
			},
			wantErr: fmt.Errorf("Invalid Path"),
		},

		// API: /api/v1/agree/{player_id}
		{
			name: "#5: When request path is valid for [ /api/v1/agree/12001 ]",
			args: args{
				request: events.APIGatewayProxyRequest{
					Resource:   "/api/v1/agree/{player_id}",
					Path:       "/api/v1/agree/12001",
					HTTPMethod: "GET",
					Headers: map[string]string{
						"Content-Type": "application/json",
						"api_key":      "test-3",
						"request_id":   "C713F659-1ABF-4EDF-8E86-655295CF7CD7",
					},
					QueryStringParameters: map[string]string{
						"timezone": "Europe/London",
					},
					PathParameters: map[string]string{
						"proxy": "example",
					},
					Body:            "",
					IsBase64Encoded: false,
					RequestContext: events.APIGatewayProxyRequestContext{
						AccountID:  "123456789012",
						ResourceID: "resource-id",
						Stage:      "prod",
						RequestID:  "request-id",
						Identity: events.APIGatewayRequestIdentity{
							CognitoIdentityPoolID: "",
							AccountID:             "",
							CognitoIdentityID:     "",
							Caller:                "",
							APIKey:                "",
							SourceIP:              "127.0.0.1",
							AccessKey:             "",
						},
					},
				},
			},
			want:    nil,
			wantErr: nil,
		},
		{
			name: "#6: Invalid request path",
			args: args{
				request: events.APIGatewayProxyRequest{
					Resource:   "/api/v1/agree/12001/21313",
					Path:       "/api/v1/agree/12002/1232",
					HTTPMethod: "GET",
					Headers: map[string]string{
						"Content-Type": "application/json",
						"api_key":      "test-3",
						"request_id":   "C713F659-1ABF-4EDF-8E86-655295CF7CD7",
					},
					QueryStringParameters: map[string]string{
						"timezone": "Europe/London",
					},
					PathParameters: map[string]string{
						"proxy": "example",
					},
					Body:            "",
					IsBase64Encoded: false,
					RequestContext: events.APIGatewayProxyRequestContext{
						AccountID:  "123456789012",
						ResourceID: "resource-id",
						Stage:      "prod",
						RequestID:  "request-id",
						Identity: events.APIGatewayRequestIdentity{
							CognitoIdentityPoolID: "",
							AccountID:             "",
							CognitoIdentityID:     "",
							Caller:                "",
							APIKey:                "",
							SourceIP:              "127.0.0.1",
							AccessKey:             "",
						},
					},
				},
			},
			want: &events.APIGatewayProxyResponse{
				StatusCode:      200,
				Headers:         responseHeaders,
				Body:            string(createResponseBody(int(v3.ResponseInvalidRequestPath), nil)),
				IsBase64Encoded: false,
			},
			wantErr: fmt.Errorf("Invalid Path"),
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got, err := ValidateRequestPath(tt.args.request)
			if err != nil && err == tt.wantErr {
				t.Errorf("ValidateRequestPath() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
			if !reflect.DeepEqual(got, tt.want) {
				t.Errorf("ValidateRequestPath() got = %v, want %v", got, tt.want)
			}
		})
	}
}

func TestValidateQueryStringParams(t *testing.T) {
	type args struct {
		request events.APIGatewayProxyRequest
	}
	tests := []struct {
		name    string
		args    args
		want    *QueryStringParams
		want1   *events.APIGatewayProxyResponse
		wantErr error
	}{
		{
			name: "#1: When send query string params timezone [Europe/London]",
			args: args{
				request: events.APIGatewayProxyRequest{
					Resource:   "/api/v1/required_agreements",
					Path:       "/api/v1/required_agreements",
					HTTPMethod: "GET",
					Headers: map[string]string{
						"Content-Type": "application/json",
						"api_key":      "test-3",
						"request_id":   "C713F659-1ABF-4EDF-8E86-655295CF7CD7",
					},
					QueryStringParameters: map[string]string{
						"timezone": "Europe/London",
					},
					PathParameters: map[string]string{
						"proxy": "example",
					},
					Body:            "",
					IsBase64Encoded: false,
					RequestContext: events.APIGatewayProxyRequestContext{
						AccountID:  "123456789012",
						ResourceID: "resource-id",
						Stage:      "prod",
						RequestID:  "request-id",
						Identity: events.APIGatewayRequestIdentity{
							CognitoIdentityPoolID: "",
							AccountID:             "",
							CognitoIdentityID:     "",
							Caller:                "",
							APIKey:                "",
							SourceIP:              "127.0.0.1",
							AccessKey:             "",
						},
					},
				},
			},
			want: &QueryStringParams{
				Timezone: "Europe/London",
			},
			want1:   nil,
			wantErr: nil,
		},
		{
			name: "#2: When send query string params timezone is empty",
			args: args{
				request: events.APIGatewayProxyRequest{
					Resource:   "/api/v1/required_agreements",
					Path:       "/api/v1/required_agreements/old",
					HTTPMethod: "GET",
					Headers: map[string]string{
						"Content-Type": "application/json",
						"api_key":      "test-3",
						"request_id":   "C713F659-1ABF-4EDF-8E86-655295CF7CD7",
					},
					QueryStringParameters: map[string]string{
						"timezone": "",
					},
					PathParameters: map[string]string{
						"proxy": "example",
					},
					Body:            "",
					IsBase64Encoded: false,
					RequestContext: events.APIGatewayProxyRequestContext{
						AccountID:  "123456789012",
						ResourceID: "resource-id",
						Stage:      "prod",
						RequestID:  "request-id",
						Identity: events.APIGatewayRequestIdentity{
							CognitoIdentityPoolID: "",
							AccountID:             "",
							CognitoIdentityID:     "",
							Caller:                "",
							APIKey:                "",
							SourceIP:              "127.0.0.1",
							AccessKey:             "",
						},
					},
				},
			},
			want: &QueryStringParams{},
			want1: &events.APIGatewayProxyResponse{
				StatusCode:      200,
				Headers:         responseHeaders,
				Body:            string(createResponseBody(int(ResponseMissingTimezone), nil)),
				IsBase64Encoded: false,
			},
			wantErr: fmt.Errorf("Timezone required"),
		},
		{
			name: "#3: When send no query string params",
			args: args{
				request: events.APIGatewayProxyRequest{
					Resource:   "/api/v1/required_agreements",
					Path:       "/api/v1/required_agreements/old",
					HTTPMethod: "GET",
					Headers: map[string]string{
						"Content-Type": "application/json",
						"api_key":      "test-3",
						"request_id":   "C713F659-1ABF-4EDF-8E86-655295CF7CD7",
					},
					PathParameters: map[string]string{
						"proxy": "example",
					},
					Body:            "",
					IsBase64Encoded: false,
					RequestContext: events.APIGatewayProxyRequestContext{
						AccountID:  "123456789012",
						ResourceID: "resource-id",
						Stage:      "prod",
						RequestID:  "request-id",
						Identity: events.APIGatewayRequestIdentity{
							CognitoIdentityPoolID: "",
							AccountID:             "",
							CognitoIdentityID:     "",
							Caller:                "",
							APIKey:                "",
							SourceIP:              "127.0.0.1",
							AccessKey:             "",
						},
					},
				},
			},
			want: nil,
			want1: &events.APIGatewayProxyResponse{
				StatusCode:      200,
				Headers:         responseHeaders,
				Body:            string(createResponseBody(int(ResponseMissingTimezone), nil)),
				IsBase64Encoded: false,
			},
			wantErr: fmt.Errorf("Timezone required"),
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got, got1, err := ValidateQueryStringParams(tt.args.request)
			if err != nil && err.Error() != tt.wantErr.Error() { //err != nil &&
				t.Errorf("ValidateQueryStringParams() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
			if !reflect.DeepEqual(got, tt.want) {
				t.Errorf("ValidateQueryStringParams() got = %v, want %v", got, tt.want)
			}
			if !reflect.DeepEqual(got1, tt.want1) {
				t.Errorf("ValidateQueryStringParams() got1 = %v, want1 %v", got1, tt.want1)
			}
		})
	}
}

func TestGetUniqueAgreementsForJurisdiction(t *testing.T) {
	type args struct {
		jurisdiction string
	}
	tests := []struct {
		name    string
		args    args
		want    []DynamoJurisdictionMapping
		wantErr error
	}{
		{
			name: "#1: Data available in Dynamo Table [jurisdiction is gdpr]",
			args: args{
				jurisdiction: "gdpr",
			},
			want: []DynamoJurisdictionMapping{
				{
					Jurisdiction:    "gdpr",
					Agreement:       "tou",
					AgreementLocale: "en-uk",
					Version:         "1681118745",
				},
				{
					Jurisdiction:    "gdpr",
					Agreement:       "pp",
					AgreementLocale: "en-uk",
					Version:         "1681118791",
				},
			},
			wantErr: nil,
		},
		{
			name: "#2: Data available in Dynamo Table [jurisdiction is eu]",
			args: args{
				jurisdiction: "eu",
			},
			want: []DynamoJurisdictionMapping{
				{
					Jurisdiction:    "eu",
					Agreement:       "pp",
					AgreementLocale: "en-uk",
					Version:         "1680845499",
				},
				{
					Jurisdiction:    "eu",
					Agreement:       "tou",
					AgreementLocale: "en-uk",
					Version:         "1680846146",
				},
			},
			wantErr: nil,
		},
		{
			name: "#3: Data not found in Dynamo table [Jurisdiction is pipl]",
			args: args{
				jurisdiction: "pipl",
			},
			want:    nil,
			wantErr: nil,
		},
		{
			name: "#4: Generate an error in dynamo query",
			args: args{
				jurisdiction: "test",
			},
			want:    nil,
			wantErr: fmt.Errorf("something went wrong"),
		},
	}

	env = NewEnv()
	dynamoSvc = &MockDynamoClient{}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got, err := GetUniqueAgreementsForJurisdiction(dynamoSvc, tt.args.jurisdiction)
			if (err != nil) && err.Error() != tt.wantErr.Error() {
				t.Errorf("GetUniqueAgreementsForJurisdiction() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
			if !reflect.DeepEqual(got, tt.want) {
				t.Errorf("GetUniqueAgreementsForJurisdiction() got= %v, want %v", got, tt.want)
			}
		})
	}
}

func TestHandlerRequest(t *testing.T) {
	parameterStore = &im_config.MockKeyClient{
		FileBytes: []byte(`{"keys":[{"key":"/honeybadger/admin/api_key","value":{"Name":"/honeybadger/admin/api_key","Value":"api_key"}}]}`),
	}

	type args struct {
		ctx     context.Context
		request events.APIGatewayProxyRequest
	}

	setEnvVars(map[TypeEnvVar]string{
		ENV_APPLICATION_NAME:           "consent_management",
		ENV_LOG_LEVEL:                  "debug",
		ENV_AWS_REGION:                 "us-east-1",
		ENV_PARAMETERS_STORE:           "/tmp/parameters.txt",
		ENV_DYNAMO_CONSENT_TABLE_NAME:  "consent_management_test",
		ENV_DYNAMO_API_KEYS_TABLE_NAME: "api_keys_test",
		ENV_DYNAMO_MAPPING_TABLE_NAME:  "jurisdiction_mapping_test",
		ENV_CLOUDFRONT_HOST_URL:        "https://test.cloudfront.net",
	})

	tests := []struct {
		name    string
		args    args
		want    events.APIGatewayProxyResponse
		wantErr bool
	}{
		// API: /api/v1/required_agreements
		{
			name: "#1: Success API request",
			args: args{
				request: events.APIGatewayProxyRequest{
					Resource:   "/api/v1/required_agreements",
					Path:       "/api/v1/required_agreements",
					HTTPMethod: "GET",
					Headers: map[string]string{
						"Content-Type":   "application/json",
						"api_key":        "test-api-key",
						"request_id":     "8713F659-1ABF-4EDF-8E86-655295CF7CD9",
						"correlation_id": "test-correlation-id",
					},
					QueryStringParameters: map[string]string{
						"timezone": "Europe/London",
					},
					PathParameters: map[string]string{
						"proxy": "example",
					},
					Body:            "",
					IsBase64Encoded: false,
					RequestContext: events.APIGatewayProxyRequestContext{
						AccountID:  "123456789012",
						ResourceID: "resource-id",
						Stage:      "prod",
						RequestID:  "request-id",
						Identity: events.APIGatewayRequestIdentity{
							CognitoIdentityPoolID: "",
							AccountID:             "",
							CognitoIdentityID:     "",
							Caller:                "",
							APIKey:                "",
							SourceIP:              "127.0.0.1",
							AccessKey:             "",
						},
					},
				},
				ctx: context.TODO(),
			},
			want: events.APIGatewayProxyResponse{
				StatusCode: 200,
				Headers: map[string]string{
					"api_key":        "test-api-key",
					"request_id":     "8713F659-1ABF-4EDF-8E86-655295CF7CD9",
					"correlation_id": "test-correlation-id",
				},
				Body:            `{"error":0,"data":[{"jurisdiction":"gdpr","agreement":"tou","version":"1681118745","locale":"en-uk","url":"https://test.cloudfront.net/agreement/gdpr/en-uk/tou/1681118745/tou.html"},{"jurisdiction":"gdpr","agreement":"pp","version":"1681118791","locale":"en-uk","url":"https://test.cloudfront.net/agreement/gdpr/en-uk/pp/1681118791/pp.html"}]}`,
				IsBase64Encoded: false,
			},
			wantErr: false,
		},
		{
			name: "#2: Missing API Key from headers",
			args: args{
				request: events.APIGatewayProxyRequest{
					Resource:   "/api/v1/required_agreements",
					Path:       "/api/v1/required_agreements",
					HTTPMethod: "GET",
					Headers: map[string]string{
						"Content-Type":   "application/json",
						"request_id":     "8713F659-1ABF-4EDF-8E86-655295CF7CD9",
						"correlation_id": "correlation_id-1",
					},
					QueryStringParameters: map[string]string{
						"timezone": "Europe/London",
					},
					PathParameters: map[string]string{
						"proxy": "example",
					},
					Body:            "",
					IsBase64Encoded: false,
					RequestContext: events.APIGatewayProxyRequestContext{
						AccountID:  "123456789012",
						ResourceID: "resource-id",
						Stage:      "prod",
						RequestID:  "request-id",
						Identity: events.APIGatewayRequestIdentity{
							CognitoIdentityPoolID: "",
							AccountID:             "",
							CognitoIdentityID:     "",
							Caller:                "",
							APIKey:                "",
							SourceIP:              "127.0.0.1",
							AccessKey:             "",
						},
					},
				},
				ctx: context.TODO(),
			},
			want: events.APIGatewayProxyResponse{
				StatusCode: 200,
				Headers: map[string]string{
					"request_id":     "8713F659-1ABF-4EDF-8E86-655295CF7CD9",
					"correlation_id": "correlation_id-1",
				},
				Body:            fmt.Sprintf(`{"error":%d,"data":null}`, int(v3.ResponseMissingApiKey)),
				IsBase64Encoded: false,
			},
			wantErr: false,
		},
		{
			name: "#3: Empty api_key",
			args: args{
				request: events.APIGatewayProxyRequest{
					Resource:   "/api/v1/required_agreements",
					Path:       "/api/v1/required_agreements",
					HTTPMethod: "GET",
					Headers: map[string]string{
						"Content-Type":   "application/json",
						"api_key":        "",
						"request_id":     "8713F659-1ABF-4EDF-8E86-655295CF7CD9",
						"correlation_id": "correlation_id-1",
					},
					QueryStringParameters: map[string]string{
						"timezone": "Europe/London",
					},
					PathParameters: map[string]string{
						"proxy": "example",
					},
					Body:            "",
					IsBase64Encoded: false,
					RequestContext: events.APIGatewayProxyRequestContext{
						AccountID:  "123456789012",
						ResourceID: "resource-id",
						Stage:      "prod",
						RequestID:  "request-id",
						Identity: events.APIGatewayRequestIdentity{
							CognitoIdentityPoolID: "",
							AccountID:             "",
							CognitoIdentityID:     "",
							Caller:                "",
							APIKey:                "",
							SourceIP:              "127.0.0.1",
							AccessKey:             "",
						},
					},
				},
				ctx: context.TODO(),
			},
			want: events.APIGatewayProxyResponse{
				StatusCode: 200,
				Headers: map[string]string{
					"request_id":     "8713F659-1ABF-4EDF-8E86-655295CF7CD9",
					"correlation_id": "correlation_id-1",
					"api_key":        "",
				},
				Body:            fmt.Sprintf(`{"error":%d,"data":null}`, int(v3.ResponseMissingApiKey)),
				IsBase64Encoded: false,
			},
			wantErr: false,
		},
		{
			name: "#4: Invalid request_id in headers",
			args: args{
				request: events.APIGatewayProxyRequest{
					Resource:   "/api/v1/required_agreements",
					Path:       "/api/v1/required_agreements",
					HTTPMethod: "GET",
					Headers: map[string]string{
						"Content-Type":   "application/json",
						"api_key":        "test-3",
						"request_id":     "",
						"correlation_id": "correlation_id-1",
					},
					QueryStringParameters: map[string]string{
						"timezone": "Europe/London",
					},
					PathParameters: map[string]string{
						"proxy": "example",
					},
					Body:            "",
					IsBase64Encoded: false,
					RequestContext: events.APIGatewayProxyRequestContext{
						AccountID:  "123456789012",
						ResourceID: "resource-id",
						Stage:      "prod",
						RequestID:  "request-id",
						Identity: events.APIGatewayRequestIdentity{
							CognitoIdentityPoolID: "",
							AccountID:             "",
							CognitoIdentityID:     "",
							Caller:                "",
							APIKey:                "",
							SourceIP:              "127.0.0.1",
							AccessKey:             "",
						},
					},
				},
				ctx: context.TODO(),
			},
			want: events.APIGatewayProxyResponse{
				StatusCode: 200,
				Headers: map[string]string{
					"api_key":        "test-3",
					"correlation_id": "correlation_id-1",
					"request_id":     "",
				},
				Body:            fmt.Sprintf(`{"error":%d,"data":null}`, int(v3.ResponseInvalidRequestIdHeader)),
				IsBase64Encoded: false,
			},
			wantErr: false,
		},
		{
			name: "#5: Missing correlation_id",
			args: args{
				request: events.APIGatewayProxyRequest{
					Resource:   "/api/v1/required_agreements",
					Path:       "/api/v1/required_agreements",
					HTTPMethod: "GET",
					Headers: map[string]string{
						"Content-Type": "application/json",
						"api_key":      "test-api-key-1",
						"request_id":   "8713F659-1ABF-4EDF-8E86-655295CF7CD9",
						// "correlation_id": "correlation_id-1",
					},
					QueryStringParameters: map[string]string{
						"timezone": "Europe/London",
					},
					PathParameters: map[string]string{
						"proxy": "example",
					},
					Body:            "",
					IsBase64Encoded: false,
					RequestContext: events.APIGatewayProxyRequestContext{
						AccountID:  "123456789012",
						ResourceID: "resource-id",
						Stage:      "prod",
						RequestID:  "request-id",
						Identity: events.APIGatewayRequestIdentity{
							CognitoIdentityPoolID: "",
							AccountID:             "",
							CognitoIdentityID:     "",
							Caller:                "",
							APIKey:                "",
							SourceIP:              "127.0.0.1",
							AccessKey:             "",
						},
					},
				},
				ctx: context.TODO(),
			},
			want: events.APIGatewayProxyResponse{
				StatusCode: 200,
				Headers: map[string]string{
					"request_id": "8713F659-1ABF-4EDF-8E86-655295CF7CD9",
					"api_key":    "test-api-key-1",
				},
				Body:            fmt.Sprintf(`{"error":%d,"data":null}`, int(v3.ResponseMissingCorrelationId)),
				IsBase64Encoded: false,
			},
			wantErr: false,
		},
		{
			name: "#6: Success API request when the timezone is within Europe [timezone: Europe/Berlin]",
			args: args{
				request: events.APIGatewayProxyRequest{
					Resource:   "/api/v1/required_agreements",
					Path:       "/api/v1/required_agreements",
					HTTPMethod: "GET",
					Headers: map[string]string{
						"Content-Type":   "application/json",
						"api_key":        "test-3",
						"request_id":     "8713F659-1ABF-4EDF-8E86-655295CF7CD9",
						"correlation_id": "correlation_id-1",
					},
					QueryStringParameters: map[string]string{
						"timezone": "Europe/London",
					},
					PathParameters: map[string]string{
						"proxy": "example",
					},
					Body:            "",
					IsBase64Encoded: false,
					RequestContext: events.APIGatewayProxyRequestContext{
						AccountID:  "123456789012",
						ResourceID: "resource-id",
						Stage:      "prod",
						RequestID:  "request-id",
						Identity: events.APIGatewayRequestIdentity{
							CognitoIdentityPoolID: "",
							AccountID:             "",
							CognitoIdentityID:     "",
							Caller:                "",
							APIKey:                "",
							SourceIP:              "127.0.0.1",
							AccessKey:             "",
						},
					},
				},
				ctx: context.TODO(),
			},
			want: events.APIGatewayProxyResponse{
				StatusCode: 200,
				Headers: map[string]string{
					"api_key":        "test-3",
					"request_id":     "8713F659-1ABF-4EDF-8E86-655295CF7CD9",
					"correlation_id": "correlation_id-1",
				},
				Body:            fmt.Sprintf(`{"error":%d,"data":[{"jurisdiction":"gdpr","agreement":"tou","version":"1681118745","locale":"en-uk","url":"https://test.cloudfront.net/agreement/gdpr/en-uk/tou/1681118745/tou.html"},{"jurisdiction":"gdpr","agreement":"pp","version":"1681118791","locale":"en-uk","url":"https://test.cloudfront.net/agreement/gdpr/en-uk/pp/1681118791/pp.html"}]}`, int(v3.ResponseSuccess)),
				IsBase64Encoded: false,
			},
			wantErr: false,
		},
		{
			name: "#7: Empty agreement list while the timezone is outside of Europe [timezone: Asia/Kabul]",
			args: args{
				request: events.APIGatewayProxyRequest{
					Resource:   "/api/v1/required_agreements",
					Path:       "/api/v1/required_agreements",
					HTTPMethod: "GET",
					Headers: map[string]string{
						"Content-Type":   "application/json",
						"api_key":        "test-3",
						"request_id":     "8713F659-1ABF-4EDF-8E86-655295CF7CD9",
						"correlation_id": "correlation_id-1",
					},
					QueryStringParameters: map[string]string{
						"timezone": "Asia/Kabul",
					},
					PathParameters: map[string]string{
						"proxy": "example",
					},
					Body:            "",
					IsBase64Encoded: false,
					RequestContext: events.APIGatewayProxyRequestContext{
						AccountID:  "123456789012",
						ResourceID: "resource-id",
						Stage:      "prod",
						RequestID:  "request-id",
						Identity: events.APIGatewayRequestIdentity{
							CognitoIdentityPoolID: "",
							AccountID:             "",
							CognitoIdentityID:     "",
							Caller:                "",
							APIKey:                "",
							SourceIP:              "127.0.0.1",
							AccessKey:             "",
						},
					},
				},
				ctx: context.TODO(),
			},
			want: events.APIGatewayProxyResponse{
				StatusCode: 200,
				Headers: map[string]string{
					"api_key":        "test-3",
					"request_id":     "8713F659-1ABF-4EDF-8E86-655295CF7CD9",
					"correlation_id": "correlation_id-1",
				},
				Body:            `{"error":0,"data":[]}`,
				IsBase64Encoded: false,
			},
			wantErr: false,
		},
		{
			name: "#8: Invalid timezone",
			args: args{
				request: events.APIGatewayProxyRequest{
					Resource:   "/api/v1/required_agreements",
					Path:       "/api/v1/required_agreements",
					HTTPMethod: "GET",
					Headers: map[string]string{
						"Content-Type":   "application/json",
						"api_key":        "test-3",
						"request_id":     "8713F659-1ABF-4EDF-8E86-655295CF7CD9",
						"correlation_id": "correlation_id-1",
					},
					QueryStringParameters: map[string]string{
						"timezone": "",
					},
					PathParameters: map[string]string{
						"proxy": "example",
					},
					Body:            "",
					IsBase64Encoded: false,
					RequestContext: events.APIGatewayProxyRequestContext{
						AccountID:  "123456789012",
						ResourceID: "resource-id",
						Stage:      "prod",
						RequestID:  "request-id",
						Identity: events.APIGatewayRequestIdentity{
							CognitoIdentityPoolID: "",
							AccountID:             "",
							CognitoIdentityID:     "",
							Caller:                "",
							APIKey:                "",
							SourceIP:              "127.0.0.1",
							AccessKey:             "",
						},
					},
				},
				ctx: context.TODO(),
			},
			want: events.APIGatewayProxyResponse{
				StatusCode: 200,
				Headers: map[string]string{
					"api_key":        "test-3",
					"request_id":     "8713F659-1ABF-4EDF-8E86-655295CF7CD9",
					"correlation_id": "correlation_id-1",
				},
				Body:            fmt.Sprintf(`{"error":%d,"data":null}`, int(ResponseMissingTimezone)),
				IsBase64Encoded: false,
			},
			wantErr: false,
		},
		{
			name: "#9: Missing timezone from Query Params",
			args: args{
				request: events.APIGatewayProxyRequest{
					Resource:   "/api/v1/required_agreements",
					Path:       "/api/v1/required_agreements",
					HTTPMethod: "GET",
					Headers: map[string]string{
						"Content-Type":   "application/json",
						"api_key":        "test-3",
						"request_id":     "8713F659-1ABF-4EDF-8E86-655295CF7CD9",
						"correlation_id": "correlation_id-1",
					},
					QueryStringParameters: map[string]string{
						"test": "",
					},
					PathParameters: map[string]string{
						"proxy": "example",
					},
					Body:            "",
					IsBase64Encoded: false,
					RequestContext: events.APIGatewayProxyRequestContext{
						AccountID:  "123456789012",
						ResourceID: "resource-id",
						Stage:      "prod",
						RequestID:  "request-id",
						Identity: events.APIGatewayRequestIdentity{
							CognitoIdentityPoolID: "",
							AccountID:             "",
							CognitoIdentityID:     "",
							Caller:                "",
							APIKey:                "",
							SourceIP:              "127.0.0.1",
							AccessKey:             "",
						},
					},
				},
				ctx: context.TODO(),
			},
			want: events.APIGatewayProxyResponse{
				StatusCode: 200,
				Headers: map[string]string{
					"api_key":        "test-3",
					"request_id":     "8713F659-1ABF-4EDF-8E86-655295CF7CD9",
					"correlation_id": "correlation_id-1",
				},
				Body:            fmt.Sprintf(`{"error":%d,"data":null}`, int(ResponseMissingTimezone)),
				IsBase64Encoded: false,
			},
			wantErr: false,
		},
		{
			name: "#10: Invalid Request Method",
			args: args{
				request: events.APIGatewayProxyRequest{
					Resource:   "/api/v1/required_agreements",
					Path:       "/api/v1/required_agreements",
					HTTPMethod: "PUT",
					Headers: map[string]string{
						"Content-Type":   "application/json",
						"api_key":        "test-3",
						"request_id":     "8713F659-1ABF-4EDF-8E86-655295CF7CD9",
						"correlation_id": "correlation_id-1",
					},
					QueryStringParameters: map[string]string{
						"timezone": "Europe/London",
					},
					PathParameters: map[string]string{
						"proxy": "example",
					},
					Body:            "",
					IsBase64Encoded: false,
					RequestContext: events.APIGatewayProxyRequestContext{
						AccountID:  "123456789012",
						ResourceID: "resource-id",
						Stage:      "prod",
						RequestID:  "request-id",
						Identity: events.APIGatewayRequestIdentity{
							CognitoIdentityPoolID: "",
							AccountID:             "",
							CognitoIdentityID:     "",
							Caller:                "",
							APIKey:                "",
							SourceIP:              "127.0.0.1",
							AccessKey:             "",
						},
					},
				},
				ctx: context.TODO(),
			},
			want: events.APIGatewayProxyResponse{
				StatusCode: 200,
				Headers: map[string]string{
					"api_key":        "test-3",
					"request_id":     "8713F659-1ABF-4EDF-8E86-655295CF7CD9",
					"correlation_id": "correlation_id-1",
				},
				Body:            fmt.Sprintf(`{"error":%d,"data":null}`, int(v3.ResponseInvalidRequestMethod)),
				IsBase64Encoded: false,
			},
			wantErr: false,
		},
		{
			name: "#11: Invalid Request Path",
			args: args{
				request: events.APIGatewayProxyRequest{
					Resource:   "/api/v1/required",
					Path:       "/api/v1/required",
					HTTPMethod: "GET",
					Headers: map[string]string{
						"Content-Type":   "application/json",
						"api_key":        "test-3",
						"request_id":     "8713F659-1ABF-4EDF-8E86-655295CF7CD9",
						"correlation_id": "correlation_id-1",
					},
					QueryStringParameters: map[string]string{
						"timezone": "Europe/London",
					},
					PathParameters: map[string]string{
						"proxy": "example",
					},
					Body:            "",
					IsBase64Encoded: false,
					RequestContext: events.APIGatewayProxyRequestContext{
						AccountID:  "123456789012",
						ResourceID: "resource-id",
						Stage:      "prod",
						RequestID:  "request-id",
						Identity: events.APIGatewayRequestIdentity{
							CognitoIdentityPoolID: "",
							AccountID:             "",
							CognitoIdentityID:     "",
							Caller:                "",
							APIKey:                "",
							SourceIP:              "127.0.0.1",
							AccessKey:             "",
						},
					},
				},
				ctx: context.TODO(),
			},
			want: events.APIGatewayProxyResponse{
				StatusCode: 200,
				Headers: map[string]string{
					"api_key":        "test-3",
					"request_id":     "8713F659-1ABF-4EDF-8E86-655295CF7CD9",
					"correlation_id": "correlation_id-1",
				},
				Body:            fmt.Sprintf(`{"error":%d,"data":null}`, int(v3.ResponseInvalidRequestPath)),
				IsBase64Encoded: false,
			},
			wantErr: false,
		},
	}

	env = NewEnv()

	dynamoSvc = &MockDynamoClient{}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			response, _ := HandleRequest(tt.args.ctx, tt.args.request)
			if !reflect.DeepEqual(response, tt.want) {
				t.Errorf("HandleRequest() response = %v, wantResponse %v", response, tt.want)
			}
		})
	}
}
