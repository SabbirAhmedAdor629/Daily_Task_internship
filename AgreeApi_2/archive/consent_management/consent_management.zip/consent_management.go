package main

import (
	"context"
	"encoding/json"
	"fmt"
	"net/http"
	"os"
	"regexp"
	"strconv"
	"strings"
	"time"

	"github.com/google/uuid"

	"github.com/aws/aws-lambda-go/events"
	"github.com/aws/aws-lambda-go/lambda"
	"github.com/honeybadger-io/honeybadger-go"

	"github.com/aws/aws-sdk-go/aws/session"
	"github.com/aws/aws-sdk-go/service/dynamodb"
	"github.com/aws/aws-sdk-go/service/dynamodb/dynamodbiface"
	im_keycache "influencemobile.com/libs/api_key"
	im_badger "influencemobile.com/libs/badger"
	v3 "influencemobile.com/libs/v3_helpers"
	. "influencemobile.com/logging"
	im_config "influencemobile.com/parameter_store"
)

var (
	logger         *Loggers
	env            envVars
	dynamoSvc      dynamodbiface.DynamoDBAPI
	opCounters     *OperationalCounters
	apiKeys        im_keycache.ApiKeyType
	badger         im_badger.BadgerIface
	parameterStore im_config.ParameterStoreIface
)

var (
	validApiPaths = []*regexp.Regexp{
		regexp.MustCompile("^/api/v1/required_agreements$"),
		regexp.MustCompile("^/api/v1/required_agreements/(?P<player_id>[^/]+)$"),
		regexp.MustCompile("^/api/v1/agree/(?P<player_id>[^/]+)$"),
	}

	expectedAllRequestHeaders = []string{"api_key", "request_id", "correlation_id"}

	endpointsMandatoryHeaders = map[string][]string{
		"/api/v1/required_agreements":             {"api_key", "request_id", "correlation_id"},
		"/api/v1/required_agreements/{player_id}": {"api_key", "request_id", "correlation_id"},
		"/api/v1/agree/{player_id}":               {"api_key", "request_id"},
	}

	mandatoryParameters = []string{
		"jurisdiction",
		"agreement",
		"version",
		"locale",
		"timestamp",
	}

	validAgreementList = []string{"pp", "tou"}

	validLocaleList = []string{"en-uk"}
)

var responseHeaders map[string]string

type HoneyBadgerType struct {
	Name  string
	Value string
}

type (
	dynamoClient      struct{ dynamodbiface.DynamoDBAPI }
	QueryStringParams struct {
		Timezone string `json:"timezone"`
	}
)

type APIResponseBody string

type ResponseObject struct {
	Error int         `json:"error"`
	Data  []Agreement `json:"data"`
}

type Agreement struct {
	Jurisdiction string `json:"jurisdiction"`
	Agreement    string `json:"agreement"`
	Version      string `json:"version"`
	Locale       string `json:"locale"`
	URL          string `json:"url"`
}

type DynamoJurisdictionMapping struct {
	Jurisdiction    string `json:"jurisdiction"`
	Agreement       string `json:"agreement"`
	Version         string `json:"version"`
	AgreementLocale string `json:"agreement_locale"`
}

func ValidateRequestPath(request events.APIGatewayProxyRequest) (*events.APIGatewayProxyResponse, error) {
	for _, validPath := range validApiPaths {
		if path := validPath.FindStringSubmatch(request.Path); path != nil {
			return nil, nil
		}
	}

	return GenerateApiResponse(int(v3.ResponseInvalidRequestPath), nil, http.StatusOK, responseHeaders), fmt.Errorf("Invalid Path")
}

func ValidateQueryStringParams(request events.APIGatewayProxyRequest) (*QueryStringParams, *events.APIGatewayProxyResponse, error) {
	params, err := getQueryStringParams(request)
	if err != nil {
		return params, GenerateApiResponse(int(v3.ResponseInternalServerError), nil, http.StatusOK, responseHeaders), err
	}

	if params == nil || params.Timezone == "" {
		return params, GenerateApiResponse(int(ResponseMissingTimezone), nil, http.StatusOK, responseHeaders), fmt.Errorf("Timezone required")
	}

	return params, nil, nil
}

func getQueryStringParams(request events.APIGatewayProxyRequest) (*QueryStringParams, error) {
	queryJsonData, err := json.Marshal(request.QueryStringParameters)
	if err != nil {
		return nil, fmt.Errorf("Cannot retrieve parameters")
	}

	queryStringParams := &QueryStringParams{}
	if err := json.Unmarshal(queryJsonData, &queryStringParams); err != nil {
		return nil, fmt.Errorf("Cannot retrieve parameters")
	}
	return queryStringParams, nil
}

func SetJurisdiction(timezone string) string {
	if strings.HasPrefix(strings.ToLower(timezone), "europe/") {
		return "gdpr"
	}
	return ""
}

func SetConsentUrl(hostUrl string, jurisdiction string, language string, document_type string, version string) string {
	return fmt.Sprintf("%s/agreement/%s/%s/%s/%s/%s.html", hostUrl, jurisdiction, language, document_type, version, document_type)
}

func CreateAgreement(jurisdiction, agreement, version, locale string) Agreement {
	return Agreement{
		Jurisdiction: jurisdiction,
		Agreement:    agreement,
		Version:      version,
		Locale:       locale,
		URL:          SetConsentUrl(env.CloudfrontHostUrl, jurisdiction, locale, agreement, version),
	}
}

func ValidateBodyParams(requestBody string, mandatoryParams []string) ([]map[string]interface{}, int, error) {
	bodyParams := []map[string]interface{}{}
	if err := json.Unmarshal([]byte(requestBody), &bodyParams); err != nil {
		return nil, int(v3.ResponseInvalidRequestBodyParameters), fmt.Errorf("Cannot retrieve body parameters")
	}

	for _, mapP := range bodyParams {
		if valid, errorCode, err := ValidateJurisdiction(mapP); !valid {
			return nil, errorCode, err
		}
		if valid, errorCode, err := ValidateAgreement(mapP); !valid {
			return nil, errorCode, err
		}
		if valid, errorCode, err := ValidateVersion(mapP); !valid {
			return nil, errorCode, err
		}
		if valid, errorCode, err := ValidateAgreementLocale(mapP); !valid {
			return nil, errorCode, err
		}
		if valid, errorCode, err := ValidateTimestamp(mapP); !valid {
			return nil, errorCode, err
		}
	}

	return bodyParams, int(v3.ResponseSuccess), nil
}

func ValidateJurisdiction(mapP map[string]interface{}) (bool, int, error) {
	if _, ok := mapP["jurisdiction"]; !ok {
		return false, int(ResponseMissingJurisdiction), fmt.Errorf("Missing jurisdiction")
	}

	if mapP["jurisdiction"] != "gdpr" {
		return false, int(ResponseInvalidJurisdiction), fmt.Errorf("Invalid Jurisdiction")
	}

	return true, int(v3.ResponseSuccess), nil
}

func ValidateAgreement(mapP map[string]interface{}) (bool, int, error) {
	if _, ok := mapP["agreement"]; !ok {
		return false, int(ResponseMissingAgreement), fmt.Errorf("Missing agreement")
	}

	if ok := AgreementTypeIsAvailable(mapP["agreement"].(string), validAgreementList); !ok {
		return false, int(ResponseInvalidAgreement), fmt.Errorf("Invalid agreement")
	}

	return true, int(v3.ResponseSuccess), nil
}

func AgreementTypeIsAvailable(agreement string, agreementsList []string) bool {
	for _, value := range agreementsList {
		if value == agreement {
			return true
		}
	}
	return false
}

func ValidateVersion(mapP map[string]interface{}) (bool, int, error) {
	if _, ok := mapP["version"]; !ok {
		return false, int(ResponseMissingVersion), fmt.Errorf("Missing version")
	}

	versionStr := mapP["version"].(string)
	version, err := strconv.Atoi(versionStr)
	if err != nil {
		return false, int(ResponseInvalidVersion), fmt.Errorf("Invalid version")
	}

	versionTime := time.Unix(int64(version), 0)
	if versionTime.IsZero() {
		return false, int(ResponseInvalidVersion), fmt.Errorf("Invalid version")
	}

	return true, int(v3.ResponseSuccess), nil
}

func ValidateAgreementLocale(mapP map[string]interface{}) (bool, int, error) {
	if _, ok := mapP["locale"]; !ok {
		return false, int(ResponseMissingLocale), fmt.Errorf("Missing locale")
	}

	for _, locale := range validLocaleList {
		if mapP["locale"] == locale {
			return true, int(v3.ResponseSuccess), nil
		}
	}

	return false, int(ResponseInvalidLocale), fmt.Errorf("Invalid locale")
}

func ValidateTimestamp(mapP map[string]interface{}) (bool, int, error) {
	if _, ok := mapP["timestamp"]; !ok {
		return false, int(ResponseMissingTimestamp), fmt.Errorf("Missing timestamp")
	}

	if ok := IsTimeWithinThreshold(time.Now().UTC(), mapP["timestamp"].(string), env.TimestampLimitSeconds); !ok {
		return false, int(ResponseInvalidTimestamp), fmt.Errorf("Invalid timestamp")
	}

	return true, int(v3.ResponseSuccess), nil
}

func IsTimeWithinThreshold(currentTime time.Time, givenTimestamp string, timeRange int) bool {
	givenTime, err := time.Parse(DEFAULT_TIME_FORMAT, givenTimestamp)
	if err != nil {
		return false
	}
	fmt.Println(currentTime)
	fmt.Println(givenTimestamp)
	diff := currentTime.Sub(givenTime)
	fmt.Println("diff", diff)
	fmt.Println(givenTime.Before(currentTime))
	// Check if the time difference is within current time and time range
	return (givenTime.Before(currentTime) || givenTime.Equal(currentTime)) && diff <= (time.Second*time.Duration(timeRange))
}

func ConsentGUID(guid uuid.UUID) string {
	return fmt.Sprintf("agree-%s", guid)
}

func StoreAgreements(playerId string, params []map[string]interface{}) (int, error) {
	for _, item := range params {
		item["guid"] = ConsentGUID(uuid.New())
		item["player_id"] = playerId
		err := PutItem(dynamoSvc, env.DynamoConsentTableName, item)
		if err != nil {
			return int(v3.ResponseInternalServerError), err
		}
	}
	return int(v3.ResponseSuccess), nil
}

func HandleRequest(ctx context.Context, request events.APIGatewayProxyRequest) (events.APIGatewayProxyResponse, error) {
	logger.
		NewEntry(log_msg_begin, LogMsgTxt).
		Debug()
	logger. // Log environment parameters received from AWS
		NewEntry(log_msg_envars, LogMsgTxt).
		WithStruct(env).
		Debug()

	logger.
		NewEntry(log_msg_request_headers, LogMsgTxt).
		Info(request.Headers)

	logger. // Log lambda parameters
		NewEntry(log_msg_request, LogMsgTxt).
		WithStruct(request).
		Debug()

	opCounters = &OperationalCounters{}

	// Attempt to load the parameters file written by the lambda extension.
	if err := parameterStore.ReadConfig(); err != nil {
		logger.
			NewEntry(log_msg_parameters_store_parse_error, LogMsgTxt).
			Error(err.Error())
		os.Exit(1)
	}

	parameters, err := parameterStore.ParameterToBytes(DEFAULT_HONEYBADGER_KEY)
	if err != nil {
		logger.
			NewEntry(log_msg_parameters_store, LogMsgTxt).
			Error(err.Error())
		os.Exit(1)
	}

	badgerApiKey := HoneyBadgerType{}

	_ = json.Unmarshal(parameters, &badgerApiKey)

	badger.Configure(honeybadger.Configuration{APIKey: badgerApiKey.Value, Env: env.Environment})

	responseHeaders = v3.CreateResponseHeaders(request.Headers, expectedAllRequestHeaders)

	// validate request path
	resp, err := ValidateRequestPath(request)
	if err != nil {
		opCounters.incInvalidPath(1)
		logger.NewEntry(log_msg_invalid_path, LogMsgTxt).WithStruct(opCounters).Error(err.Error())
		return *resp, nil
	}

	// Validate required headers
	_, code, err := v3.ValidateRequestHeaders(responseHeaders, endpointsMandatoryHeaders[request.Resource], v3.ResponseCodeToKey)
	if err != nil {
		opCounters.incInvalidRequestHeaders(1)
		logger.NewEntry(log_msg_invalid_headers, LogMsgTxt).WithStruct(opCounters).Error(err.Error())
		return *GenerateApiResponse(code, nil, http.StatusOK, responseHeaders), nil
	}

	// Validate the api key.
	var authorized bool
	authorized, code, err = v3.ValidateAuth(dynamoSvc, &apiKeys, env.DynamoApiKeysTableName, responseHeaders["api_key"])
	if err != nil {
		opCounters.incDynamoDbError(1)
		logger.NewEntry(log_msg_dynamodb_error, LogMsgTxt).WithStruct(opCounters).Error(err.Error())
		badger.Notify(err.Error(),
			honeybadger.Context{
				"ERROR_NUMBER": log_msg_dynamodb_error,
				"ERROR_TEXT":   LogMsgTxt[log_msg_dynamodb_error],
			},
			honeybadger.Tags{
				env.ApplicationName,
				env.Environment,
				LogMsgTxt[log_msg_dynamodb_error]})
		badger.Flush()
		return *GenerateApiResponse(code, nil, http.StatusOK, responseHeaders), nil
	}
	if !authorized {
		opCounters.incInvalidAuth(1)
		logger.NewEntry(log_msg_invalid_auth, LogMsgTxt).WithStruct(opCounters).Info()
		return *GenerateApiResponse(code, nil, http.StatusOK, responseHeaders), nil
	}

	switch request.HTTPMethod {
	case "GET":
		params, resp, err := ValidateQueryStringParams(request)
		if err != nil {
			opCounters.incInvalidQueryParameters(1)
			logger.NewEntry(log_msg_invalid_query_params, LogMsgTxt).WithStruct(opCounters).Error(err.Error())
			return *resp, nil
		}

		switch request.Resource {
		case "/api/v1/required_agreements":
			jurisdiction := SetJurisdiction(params.Timezone)
			if jurisdiction != "" {
				agreementsObjList, err := GetUniqueAgreementsForJurisdiction(dynamoSvc, jurisdiction)
				if err != nil {
					opCounters.incDynamoDbError(1)
					logger.NewEntry(log_msg_dynamodb_error, LogMsgTxt).WithStruct(opCounters).Error(err.Error())
					badger.Notify(err.Error(),
						honeybadger.Context{
							"ERROR_NUMBER": log_msg_dynamodb_error,
							"ERROR_TEXT":   LogMsgTxt[log_msg_dynamodb_error],
						},
						honeybadger.Tags{
							env.ApplicationName,
							env.Environment,
							LogMsgTxt[log_msg_dynamodb_error]})
					badger.Flush()
					return *resp, nil
				}

				var agreements []Agreement
				for _, agr := range agreementsObjList {
					agreement := CreateAgreement(agr.Jurisdiction, agr.Agreement, agr.Version, agr.AgreementLocale)
					agreements = append(agreements, agreement)
				}

				logger.NewEntry(log_msg_end, LogMsgTxt).WithStruct(opCounters).Info()
				return *GenerateApiResponse(int(v3.ResponseSuccess), agreements, http.StatusOK, responseHeaders), nil
			} else {
				logger.NewEntry(log_msg_end, LogMsgTxt).WithStruct(opCounters).Info()
				return *GenerateApiResponse(int(v3.ResponseSuccess), []Agreement{}, http.StatusOK, responseHeaders), nil
			}
		case "/api/v1/required_agreements/{player_id}":
			// static response
			jurisdiction := "gdpr"
			if jurisdiction != "" {
				agreements := []Agreement{
					{
						Jurisdiction: jurisdiction,
						Agreement:    "pp",
						Version:      "1",
						Locale:       "en-uk",
						URL:          SetConsentUrl(env.CloudfrontHostUrl, jurisdiction, "en-uk", "pp", "1"),
					},
					{
						Jurisdiction: jurisdiction,
						Agreement:    "tou",
						Version:      "1",
						Locale:       "en-uk",
						URL:          SetConsentUrl(env.CloudfrontHostUrl, jurisdiction, "en-uk", "tou", "1"),
					},
				}
				return *GenerateApiResponse(int(v3.ResponseSuccess), agreements, http.StatusOK, responseHeaders), nil
			}
		default:
			return *GenerateApiResponse(int(v3.ResponseInvalidRequestPath), nil, http.StatusOK, responseHeaders), nil
		}

	case "POST":
		switch request.Resource {
		case "/api/v1/agree/{player_id}":
			playerId := request.PathParameters["player_id"]
			params, code, err := ValidateBodyParams(request.Body, mandatoryParameters)
			if err != nil {
				opCounters.incInvalidBodyParameters(1)
				logger.NewEntry(log_msg_invalid_body_parameters, LogMsgTxt).WithStruct(opCounters).Error(err.Error())
				return *GenerateApiResponse(code, nil, http.StatusOK, responseHeaders), nil
			}

			code, err = StoreAgreements(playerId, params)
			if err != nil {
				opCounters.incDynamoDbError(1)
				logger.NewEntry(log_msg_dynamodb_error, LogMsgTxt).WithStruct(opCounters).Error(err.Error())
				return *GenerateApiResponse(code, nil, http.StatusOK, responseHeaders), nil
			}

			return *GenerateApiResponse(int(v3.ResponseSuccess), nil, http.StatusOK, responseHeaders), nil
		default:
			return *GenerateApiResponse(int(v3.ResponseInvalidRequestPath), nil, http.StatusOK, responseHeaders), nil
		}
	}

	return *GenerateApiResponse(int(v3.ResponseInvalidRequestMethod), nil, http.StatusOK, responseHeaders), nil
}

func init() {

	env = NewEnv()

	// Create a new logger.
	logger = NewLoggers(os.Stderr, env.LogLevel, 0).
		SetFields(Fields{
			EnvVars[ENV_APPLICATION_NAME]: env.ApplicationName,
		})

	apiKeys = im_keycache.LoadCache(im_keycache.GetApiKeys().ApiKeys)
	dynamoSvc = dynamoClient{dynamodb.New(session.New())}
	parameterStore = &im_config.KeyClient{Filename: env.ParametersStore}
	badger = &im_badger.BadgerClient{}
}

func main() {
	defer badger.Monitor()
	lambda.Start(HandleRequest)
}

// func main() {
// 	parameterStore = &im_config.MockKeyClient{
// 		FileBytes: []byte(`{"keys":[{"key":"/honeybadger/admin/api_key","value":{"Name":"/honeybadger/admin/api_key","Value":"api_key"}}]}`),
// 	}

// 	NewSetEnvVars(map[TypeEnvVar]string{
// 		ENV_APPLICATION_NAME:           "consent_management",
// 		ENV_LOG_LEVEL:                  "debug",
// 		ENV_AWS_REGION:                 "us-east-1",
// 		ENV_PARAMETERS_STORE:           "/tmp/parameters.txt",
// 		ENV_DYNAMO_CONSENT_TABLE_NAME:  "consent_management_development",
// 		ENV_DYNAMO_API_KEYS_TABLE_NAME: "api_keys_development",
// 		ENV_DYNAMO_MAPPING_TABLE_NAME:  "jurisdiction_mapping",
// 		ENV_CLOUDFRONT_HOST_URL:        "https://dd3a5ask9c6lh.cloudfront.net",
// 		ENV_TIMESTAMP_LIMIT_SECONDS:        "2133333333",
// 	})

// 	env = NewEnv()
// 	dynamoSvc = dynamoClient{dynamodb.New(session.New(&aws.Config{Region: &env.region}))}

// 	request := events.APIGatewayProxyRequest{
// 		Resource:   "/api/v1/agree/{player_id}",
// 		Path:       "/api/v1/agree/12001",
// 		HTTPMethod: "POST",
// 		Headers: map[string]string{
// 			"Content-Type": "application/json",
// 			"api_key":      "0215db20e6fac364c14b50212fe650a9",
// 			"request_id":   "C713F659-1ABF-4EDF-8E86-655295CF7CD7",
// 		},
// 		QueryStringParameters: map[string]string{},
// 		PathParameters: map[string]string{
// 			"player_id": "12001",
// 		},
// 		Body: `[
// 			{
// 				"jurisdiction": "gdpr",
// 				"agreement": "pp",
// 				"version": "3242343243",
// 				"locale": "en-uk",
// 				"timestamp": "2023-04-17T08:57:01Z"
// 			},
// 			{
// 				"jurisdiction": "gdpr",
// 				"agreement": "tou",
// 				"version": "214214214",
// 				"locale": "en-uk",
// 				"timestamp": "2023-04-17T08:57:01Z"
// 			}
// 		]`,
// 		IsBase64Encoded: false,
// 		RequestContext: events.APIGatewayProxyRequestContext{
// 			AccountID:  "123456789012",
// 			ResourceID: "resource-id",
// 			Stage:      "prod",
// 			RequestID:  "request-id",
// 			Identity: events.APIGatewayRequestIdentity{
// 				CognitoIdentityPoolID: "",
// 				AccountID:             "",
// 				CognitoIdentityID:     "",
// 				Caller:                "",
// 				APIKey:                "",
// 				SourceIP:              "127.0.0.1",
// 				AccessKey:             "",
// 			},
// 		},
// 	}
// 	fmt.Println(request.Resource)
// 	ctx := context.TODO()
// 	resp, err := HandleRequest(ctx, request)
// 	fmt.Printf("\n\n%+v\n\n", resp)
// 	fmt.Println(err)
// }

// func NewSetEnvVars(es map[TypeEnvVar]string) {
// 	for k, v := range es {
// 		os.Setenv(EnvVars[k], v)
// 	}
// }
